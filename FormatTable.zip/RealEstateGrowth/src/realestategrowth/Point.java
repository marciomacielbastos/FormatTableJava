package realestategrowth;

public class Point {
	int order;
	float value;
}

package realestategrowth;

public class RealEstate {
	int bb;
	String timeSeries;
}

package realestategrowth;

public class Segment {
	private int periodInMonths;
	private int startPoint;
	private int endPoint;
	private float growth;
	
	public Segment(int T, Point p1, Point p2){
		this.periodInMonths = T;
		if(p1.order < p2.order){
			this.startPoint = p1.order;
			this.endPoint = p2.order;
			this.growth = (p2.value-p1.value);
		}
		else{
			this.startPoint = p2.order;
			this.endPoint = p1.order;
			this.growth = (p1.value-p2.value);
		}
	}
}

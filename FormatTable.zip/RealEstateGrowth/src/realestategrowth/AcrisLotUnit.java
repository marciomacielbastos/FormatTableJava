package realestategrowth;

import java.util.ArrayList;
import java.util.List;

public class AcrisLotUnit {

	private List<String> attributes;
	
	public AcrisLotUnit(){
		attributes = new ArrayList<String>();
	}
	public void addAtribute(String s){
		this.attributes.add(s);
	}
	
	public List<String> getAtribute(){
		return attributes;
	}
	
	public String getAtribute(int a){
		return attributes.get(a);
	}
}

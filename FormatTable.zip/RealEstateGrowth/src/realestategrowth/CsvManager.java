package realestategrowth;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;


public class CsvManager {
	private String folder = "/home/marcio/Marcio/Pluto/nyc_pluto_15v1.zip.part_FILES/";
	public static void main(String[] args) {
		CsvManager obj = new CsvManager();
		int[] indexes = {69, 79, 30};
		
		String[] filePathIn = {"Mn.csv", "QN.csv", "BK.csv", "BX.csv", "SI.csv"};
		String filePathOut = "/home/marcio/Marcio/Pluto/Pluto_descript.csv";
		obj.reformatCSV(filePathIn, filePathOut, indexes);
//		System.out.println(obj.writeCSV(units, ));
	}
	public void reformatCSV(String[] filePathIn, String filePathOut, int[] indexes){
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",(?=([^\"]*\"[^\"]*\")*[^\"]*$)";
		int[] attributes = new int[indexes.length];
		for(int i = 0; i < attributes.length; i++){
			attributes[i] = 0;
		}
		try {
			for(String csvFile : filePathIn){
				br = new BufferedReader(new FileReader(folder+csvFile));
				br.readLine();
				while ((line = br.readLine()) != null) {
					line = line.replaceAll("\\\\", "");
					String[] tokens = line.split(cvsSplitBy);
					AcrisLotUnit acris = new AcrisLotUnit();				
					int i = 0;
					try{
						for(int index : indexes){
							
							String val = tokens[index].trim();
							val = val.replace(",", "-");
							if(val.equals("")){
								val = "NULL";
							}
							acris.addAtribute(val);
							if(attributes[i] < tokens[index].trim().length()){
								attributes[i] = tokens[index].trim().length();
							}
							i++;
						}
						writeCSV(acris, filePathOut);
					}catch (ArrayIndexOutOfBoundsException e) {
						System.out.println(line);
					}
					}
				}
				for(int i : attributes){
					System.out.println(i);
				}
				System.out.println("END OF READ");
			}catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
	
	public void writeCSV(AcrisLotUnit unit, String filePathOut){
		FileWriter fileWriter = null;
		String COMMA_DELIMITER = ",";
		String NEW_LINE_SEPARATOR = "\n";
		try{
			fileWriter = new FileWriter(filePathOut, true);
			List<String> values = unit.getAtribute();
			int i = values.size();
			for(String s : values){
				fileWriter.append(s);
				i--;
				if(i > 0)fileWriter.append(COMMA_DELIMITER);
				else fileWriter.append(NEW_LINE_SEPARATOR);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try{
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}
		}	
	}
}

package realestategrowth;

import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class growth {
	public static void main( String args[] ) throws SQLException{
			
		  List<Point> averages = new ArrayList<Point>();
	      // String to be scanned to find the pattern.
	      String line = "[[203, 1029801600.0], [219, 1279065600.0], [226, 1393632000.0]]";
	      String pattern = "([0-9]*,\\s[0-9]*\\.[0-9]+)";

	      // Create a Pattern object
	      Pattern r = Pattern.compile(pattern);

	      // Now create matcher object.
	      Matcher m = r.matcher(line);
	      String val = "";
	      System.out.println(val);
	      while (m.find( )) {  
			val = m.group();
			String[] tokens = val.split(",");
//			averages.add(new Point(Integer.parseInt(tokens[0]), Float.parseFloat(tokens[1])));
	      }
//	      for(Point p: averages){
//	    	  System.out.println(p.getOrder());
//	      }
	      Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:1234/furman", "root", "m2a3rcio");
	            System.out.println("Conectado!");
	            conexao.close();
	   }
}
